<?php
session_start();
include_once 'database.php';
include_once 'Product.php';

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cart = json_decode($_POST['cart'], true);
    $totalPrice = 0;
    foreach ($cart as $product_id => $quantity) {
        $productDetails = $product->getProductDetailsById($product_id);
        $totalPrice += $productDetails['price'] * $quantity;
    }

    include_once 'Order.php';
    $order = new Order($db);
    $order_id = $order->createOrder($_SESSION['user_id'], $totalPrice);

    foreach ($cart as $product_id => $quantity) {
        $order->addProductToOrder($order_id, $product_id, $quantity);
    }

    setcookie('cart', '', time() - 3600); // Clear the cart cookie
    header('Location: success.php');
}
?>

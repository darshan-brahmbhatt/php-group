<?php
class Cart {
    // Database connection and table name
    private $conn;
    private $table_name = "cart";

    // Object properties
    public $id;
    public $user_id;
    public $product_id;
    public $quantity;

    // Constructor with DB
    public function __construct($db) {
        $this->conn = $db;
    }

    // Add a product to the cart
    public function addProduct() {
        // Create query
        $query = 'INSERT INTO ' . $this->table_name . ' SET user_id = :user_id, product_id = :product_id, quantity = :quantity';

        // Prepare statement
        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->user_id = htmlspecialchars(strip_tags($this->user_id));
        $this->product_id = htmlspecialchars(strip_tags($this->product_id));
        $this->quantity = htmlspecialchars(strip_tags($this->quantity));

        // Bind data
        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':product_id', $this->product_id);
        $stmt->bindParam(':quantity', $this->quantity);

        // Execute query
        if($stmt->execute()) {
            return true;
        }

        // Print error if something goes wrong
        printf("Error: %s.\n", $stmt->error);

        return false;
    }

    // Method to add product to cart using cookies
    public function addProductToCookie($product_id, $quantity) {
        if (!isset($_COOKIE['cart'])) {
            $cart = array();
        } else {
            $cart = json_decode($_COOKIE['cart'], true);
        }
    
        if (array_key_exists($product_id, $cart)) {
            $cart[$product_id] += $quantity;
        } else {
            $cart[$product_id] = $quantity;
        }
    
        setcookie('cart', json_encode($cart), time() + (86400 * 30), "/"); // 86400 = 1 day
    }
    
   
}

<!DOCTYPE html>
<html>
<head>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
</head>
<body>
    <div class="container mt-5">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link" href="../index.php"><i class="fas fa-home"></i> Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>
            </ul>
        </div>
    </nav>

        <div class="row">
            <!-- Add Product Card -->
            <div class="col-md-3">
                <div class="card text-white bg-primary mb-3">
                    <div class="card-header">Add Product</div>
                    <div class="card-body">
                        <h5 class="card-title">Add a new product to the store</h5>
                        <a href="add_product.php" class="btn btn-light">Go to Add Product</a>
                    </div>
                </div>
            </div>
            <!-- Update Product Card -->
            <div class="col-md-3">
                <div class="card text-white bg-warning mb-3">
                    <div class="card-header">Update Product</div>
                    <div class="card-body">
                        <h5 class="card-title">Update an existing product</h5>
                        <a href="list_products.php" class="btn btn-light">Go to Update Product</a>
                    </div>
                </div>
            </div>
            <!-- Weather Section -->
            <div class="col-md-3">
                <div class="card text-white bg-info mb-3">
                    <div class="card-header">Weather</div>
                    <div class="card-body" id="weatherContainer">
                        <!-- Weather information will be loaded here dynamically -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    function fetchWeatherData() {
        var apiKey = "2c2dedd0a016419d8c6181558241904"; // Your API key
        var city = "London"; // The city you want to get the weather for
        var apiUrl = `http://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city}`;

        $.ajax({
            url: apiUrl,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                var weatherDescription = data.current.condition.text;
                var temperature = data.current.temp_c; // Temperature in Celsius

                var weatherInfo = `
                    <p>Weather in ${city}: ${weatherDescription}</p>
                    <p>Temperature: ${temperature}°C</p>
                `;

                $('#weatherContainer').html(weatherInfo);
            },
            error: function(xhr, status, error) {
                console.error('Error fetching weather data:', error);
            }
        });
    }

    // Call the function to fetch and display the weather data
    $(document).ready(function() {
        fetchWeatherData();
    });
    </script>
</body>
</html>

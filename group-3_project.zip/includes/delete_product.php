<?php

include_once 'database.php';
include_once 'Product.php';

// Get the database connection
$database = new Database();
$db = $database->getConnection();

// Create new Product object
$product = new Product($db);

// Check if 'id' parameter exists in the URL
if (isset($_GET['id'])) {
    // Set the product ID
    $product->id = $_GET['id'];

    // Call the delete method
    if ($product->delete()) {
        echo "Product deleted successfully.";
    } else {
        echo "Unable to delete product.";
    }
}
?>

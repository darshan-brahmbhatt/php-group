<?php

include_once 'database.php';
include_once 'User.php';


$database = new Database();
$db = $database->getConnection();


if($_SERVER["REQUEST_METHOD"] == "POST") {

    $user = new User($db);


    $user->username = $_POST['username'];
    $user->email = $_POST['email'];
    $user->password = $_POST['password'];


    $user_id = $user->register(); 

    if($user_id) {
        
        session_start();
        $_SESSION['user_id'] = $user_id; 
        $_SESSION['username'] = $user->username;
        header("Location: purchase.php");
    } else {
        // Registration failed, show error message
        echo "Registration failed. Please try again.";
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background: #f8f9fa;
        }
        .register-container {
            width: 300px;
            margin: 0 auto;
            margin-top: 100px;
        }
        .logo-container {
            display: flex;
            justify-content: center;
            align-items: center;
            background: #6d4e42;
            border-radius: 50%;
            width: 80px;
            height: 80px;
            margin: 0 auto;
        }
        .logo {
            display: block;
            width: 150px;
            height:150px;
            border-radius: 50%;
        }
        .register-form {
            padding: 20px;
            border: 1px solid #ced4da;
            background: #6d4e42;
            border-radius: 5px;
            color: #fff;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="register-container">
            <div class="logo-container">
                <!-- Logo -->
                <img src="../assets\TvStore.jpg" class="logo" alt="logo">
            </div>
            <!-- Registration form -->
            <form method="POST" action="register.php" class="register-form">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                <input type="submit" value="Register" class="btn btn-primary btn-block">
            </form>
            <div class="text-center mt-3">
            <a href="login.php" class="btn btn-secondary">Login</a>
        </div>
        </div>
    </div>
</body>
</html>

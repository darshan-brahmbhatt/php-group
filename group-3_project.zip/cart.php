
<?php
    session_start();
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Your Cart</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    </head>
    <body>
        <div class="container-fluid">
            <div class="top-bar">
                <h2>Your Cart</h2>
                <div class="top-bar-right">
        <a href="index.php" class="btn btn-light">Home</a>
        <a href="cart.php" class="btn btn-light"><i class="fas fa-shopping-cart"></i> Cart</a>
    </div>
                
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Your Cart Items</h5>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
   
    include_once 'includes/database.php';

   
    $database = new Database();
    $db = $database->getConnection();

   
    include_once 'includes/Product.php';

   
    $product = new Product($db);

    $totalPrice = 0;
    if (isset($_COOKIE['cart'])) {
        $cart = json_decode($_COOKIE['cart'], true);
        foreach ($cart as $product_id => $quantity) {
            // Use the instance of the Product class to call the method
            $productDetails = $product->getProductDetailsById($product_id);
            $totalPrice += $productDetails['price'] * $quantity;
            echo "<tr>";
            echo "<td><img src='includes/{$productDetails['image_url']}' width='50' alt='{$productDetails['name']}'> {$productDetails['name']}</td>";

            echo "<td id='quantity-{$product_id}'>{$quantity}</td>"; // Assign unique ID to quantity
            echo "<td id='price-{$product_id}'>{$productDetails['price']}</td>"; // Assign unique ID to price
           
            echo "</tr>";
              
        }
    } else {
        echo "<tr><td colspan='4'>Your cart is empty.</td></tr>";
    }
    ?>

                                


                                </tbody>
                            </table>
                            <h5>Total Price: $<?php echo $totalPrice; ?></h5>
    <button class="btn btn-danger" onclick="clearCart()">Clear Cart</button>
    <?php if (isset($_SESSION) && count($_SESSION) > 0): ?>
        <form action="includes/purchase.php" method="post">
    <input type="hidden" name="cart" value="<?php echo htmlspecialchars(json_encode($_COOKIE['cart'])); ?>">
    <button type="submit" class="btn btn-success">Purchase</button>
</form>

<?php else: ?>
    <a href="includes\register.php" class="btn btn-primary">Register to Purchase</a>
<?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <script>
    function updateCartUI(productId, quantity, price) {

        $(`#quantity-${productId}`).text(quantity);
        $(`#price-${productId}`).text(`$${price}`);


        let totalPrice = 0;
        $('.price').each(function() {
            totalPrice += parseFloat($(this).text().replace('$', ''));
        });
        $('#total-price').text(`$${totalPrice.toFixed(2)}`);
    }

    function addMore(productId) {
    let cart = JSON.parse(document.cookie.replace(/(?:(?:^|.*;\s*)cart\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
    if (!cart) cart = {};

    if (cart[productId]) {
        cart[productId]++;
    } else {
        cart[productId] = 1;
    }

    document.cookie = "cart=" + JSON.stringify(cart) + "; path=/";
    updateCartUI(productId, cart[productId], cart[productId] * getProductPriceById(productId));
}

function removeItem(productId) {
    let cart = JSON.parse(document.cookie.replace(/(?:(?:^|.*;\s*)cart\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
    if (!cart) cart = {};

    if (cart[productId] && cart[productId] > 1) {
        cart[productId]--;
    } else {
        delete cart[productId];
    }

    document.cookie = "cart=" + JSON.stringify(cart) + "; path=/";
    updateCartUI(productId, cart[productId] || 0, cart[productId] * getProductPriceById(productId));
}




    function clearCart() {
        
        $.ajax({
            url: 'update_cart.php',
            type: 'POST',
            data: {action: 'clear'},
            success: function(response) {
                location.reload();
            }
        });
    }
    $(document).ready(function() {
        
        if (document.cookie.indexOf('PHPSESSID') === -1) {
        
            $('.btn-success').hide();
        }
    });

        </script>
    </body>
    </html>

<?php
session_start(); // Start the session
include_once 'database.php';
include_once 'Product.php';

$database = new Database();
$db = $database->getConnection();

$product = new Product($db);
$products = $product->read();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Products</h2>
        <div class="row">
        <?php foreach ($products as $p): ?>
    <div class="col-md-4">
        <div class="card mb-4">
            <img src="<?php echo htmlspecialchars($p['image_url']); ?>" alt="Product Image" class="card-img-top">
            <div class="card-body">
                <h5 class="card-title"><?php echo htmlspecialchars($p['name']); ?></h5>
                <p class="card-text"><?php echo htmlspecialchars($p['description']); ?></p>
                <form method="POST" action="update_product.php">
                    <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
                    <button type="submit" class="btn btn-primary">Edit</button>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; ?>
        </div>
    </div>
</body>
</html>

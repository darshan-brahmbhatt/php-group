<?php
// Include your database connection script and your Product class
include_once 'database.php';
include_once 'Product.php';

// Get the database connection
$database = new Database();
$db = $database->getConnection();

// Create new Product object
$product = new Product($db);

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Set product details from form inputs
    $product->id = $_POST['id'];
    $product->name = $_POST['name'];
    $product->description = $_POST['description'];
    $product->price = $_POST['price'];
    // Use $_FILES['image'] instead of $_POST['image']
    $product->image = $_FILES['image'];

    // Call the update method
    if ($product->update()) {
        echo "Product updated successfully.";
    } else {
        echo "Unable to update product.";
    }
} else {
    // Check if 'id' parameter exists in the URL
    if (isset($_GET['id'])) {
        // Get the product details
        $product->id = $_GET['id'];
        $productDetails = $product->readOne($product->id);
        $product->name = $productDetails['name'];
        $product->description = $productDetails['description'];
        $product->price = $productDetails['price'];
        // Note: You might need to handle the image differently, depending on how you store it
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Product</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="top-bar">
            <h2>Update Product</h2>
        </div>
        <form method="POST" action="update_product.php" enctype="multipart/form-data">
            <input type="hidden" id="id" name="id" value="<?php echo isset($product->id) ? $product->id : ''; ?>">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo isset($product->name) ? $product->name : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea id="description" name="description" class="form-control" required><?php echo isset($product->description) ? $product->description : ''; ?></textarea>
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" id="price" name="price" class="form-control" value="<?php echo isset($product->price) ? $product->price : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="image">Image:</label>
                <input type="file" id="image" name="image" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Update Product</button>
        </form>
    </div>
</body>
</html>

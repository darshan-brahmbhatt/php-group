<?php
class User {
    // Database connection and table name
    private $conn;
    private $table_name = "users";

    // Object properties
    public $id;
    public $username;
    public $password;
    public $email;

    // Constructor with DB
    public function __construct($db) {
        $this->conn = $db;
    }

    
   // Register a new user
public function register() {
    // Create query
    $query = 'INSERT INTO ' . $this->table_name . ' (username, password, email) VALUES (:username, :password, :email)';

    // Prepare statement
    $stmt = $this->conn->prepare($query);

    // Clean data
    $this->username = htmlspecialchars(strip_tags($this->username));
    $this->password = htmlspecialchars(strip_tags($this->password));
    $this->email = htmlspecialchars(strip_tags($this->email));

    // Hash the password before storing it in the database
    $this->password = password_hash($this->password, PASSWORD_DEFAULT);

    // Bind data
    $stmt->bindParam(':username', $this->username);
    $stmt->bindParam(':password', $this->password);
    $stmt->bindParam(':email', $this->email);

    // Execute query
    if($stmt->execute()) {
        // Get the ID of the last inserted row
        $this->id = $this->conn->lastInsertId();
        return $this->id; // Return the user ID upon success
    }

    // Print error if something goes wrong
    printf("Error: %s.\n", $stmt->error);

    return false;
}

    // Login a user
    public function login() {
        // SQL query to get the user with the given username
        $query = "SELECT * FROM " . $this->table_name . " WHERE username = ? LIMIT 0,1";
    
        // Prepare the query
        $stmt = $this->conn->prepare($query);
    
        // Clean the username
        $this->username = htmlspecialchars(strip_tags($this->username));
    
        // Bind the username
        $stmt->bindParam(1, $this->username);
    
        // Execute the query
        $stmt->execute();
    
        // Get the row count
        $num = $stmt->rowCount();
    
        // If a user was found
        if($num > 0) {
            // Get the row
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
            // Verify the password
            if(password_verify($this->password, $row['password'])) {
                // Password is correct, return the user's details
                return $row;
            }
        }
    
        // No user was found or password is incorrect, return false
        return false;
    }
    

    
}

<?php
$hashed_password = password_hash('Password@12', PASSWORD_DEFAULT);
echo $hashed_password;
?>

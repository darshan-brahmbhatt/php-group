<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'clear') {
    
    setcookie('cart', '', time() - 3600, '/'); 
    echo "Cart cleared.";
} else {
    echo "Invalid request.";
}
?>

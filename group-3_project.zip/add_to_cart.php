<?php
include_once 'includes/database.php';
include_once 'includes/Cart.php';

$database = new Database();
$db = $database->getConnection();

$cart = new Cart($db);

if (isset($_POST['action'])) {
    $action = $_POST['action'];
    if ($action == 'add' && isset($_POST['product_id'])) {
        $product_id = $_POST['product_id'];
        $quantity = 1; // Default quantity
        $cart->addProductToCookie($product_id, $quantity);
    } elseif ($action == 'remove' && isset($_POST['product_id'])) {
        $product_id = $_POST['product_id'];
        $cart->removeProductFromCookie($product_id);
    } elseif ($action == 'clear') {
        $cart->clearCartCookie();
    }
}
?>

<?php
include_once 'includes/database.php';
include_once 'includes/Product.php';

$database = new Database();
$db = $database->getConnection();

$product = new Product($db);

$stmt = $product->read();
$num = $stmt->rowCount();

if($num>0) {
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
       
        echo "<div class='col-md-3'>"; 
        echo "<div class='card' style='width: 100%; margin: 10px;'>";
        echo "<img src='includes/{$image_url}' class='card-img-top' alt='{$name}'>";
        echo "<div class='card-body'>";
        echo "<h5 class='card-title'>{$name}</h5>";
        echo "<p class='card-text'>Price: {$price}</p>";
        echo "<a href='product_details.php?id={$id}' class='btn btn-primary'>View Details</a>";
        echo "<a href='cart.php' class='btn btn-light add-to-cart' data-product-id='{$id}'><i class='fas fa-cart-plus'></i> Add to Cart</a>"; // Updated link to navigate to cart.php
        echo "</div>";
        echo "</div>";
        echo "</div>";
    }
} else {
    echo "No products found.";
}
?>

    <?php
    // Include your database connection script and your Product class
    include_once 'database.php';
    include_once 'Product.php';

    // Get the database connection
    $database = new Database();
    $db = $database->getConnection();

    // Create new Product object
    $product = new Product($db);

    // Check if form is submitted
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        // Set product details from form inputs
        $product->name = $_POST['name'];
        $product->description = $_POST['description'];
        $product->price = $_POST['price'];
        // Use $_FILES['image'] instead of $_POST['image']
        $product->image = $_FILES['image'];

        // Replace $product->add() with $product->create()
        if($product->create()) {
            echo "Product added successfully.";
        } else {
            echo "Unable to add product.";
        }
    }

    ?>

    <!DOCTYPE html>
    <html>
    <head>
        <title>Add Product</title>

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <style>
            body {
                background: #f8f9fa;
            }
            .container {
                margin-top: 50px;
            }
            .top-bar {
                text-align: center;
                padding: 20px;
                margin-bottom: 40px;
                border-radius: 10px;
                background: #6d4e42;
                color: #fff;
            }
            form {
                background: #fff;
                padding: 20px;
                border-radius: 5px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }
            form .form-group {
                margin-bottom: 10px; /* Reduced margin */
            }
            form .btn {
                background: #6d4e42;
                display: block;
                width: 100%;
                margin-top: 10px; /* Reduced margin */
            }
            button {
                background-color: #4CAF50; /* Green */
                border: none;
                color: white;
                padding: 5px 14px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                cursor: pointer;
                border-radius: 12px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="top-bar">
                <h2>Add New Product</h2>
            </div>
            <form method="POST" action="add_product.php" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" class="form-control" required></textarea>
                </div>
                <div class="form-group">
                    <label for="price">Price:</label>
                    <input type="number" id="price" name="price" class="form-control" required>
                </div>
                <div class="form-group">
            <label for="image">Image:</label>
            <input type="file" id="image" name="image" class="form-control">
        </div>
                <button type="submit" class="btn btn-primary">Add Product</button>
            </form>
        </div>
    </body>
    </html>

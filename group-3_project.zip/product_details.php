<?php
// Include necessary files
include_once 'includes/database.php';
include_once 'includes/Product.php';
include_once 'includes/Cart.php';

// Get product ID from URL
$productId = isset($_GET['id']) ? $_GET['id'] : null;

if ($productId) {
    $database = new Database();
    $db = $database->getConnection();
    $product = new Product($db);
    try {
        $productDetails = $product->readOne($productId);
    } catch (Exception $e) {
        // Handle the exception, e.g., display an error message or redirect
        echo "Error: " . $e->getMessage();
        exit;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $productDetails['name']; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
<div class="top-bar">
    <h2>Product Details</h2>
    <div class="top-bar-right">
        <a href="index.php" class="btn btn-light">Home</a>
        <a href="cart.php" class="btn btn-light"><i class="fas fa-shopping-cart"></i> Cart</a>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            <img src="includes/<?php echo $productDetails['image_url']; ?>" class="img-fluid" alt="<?php echo $productDetails['name']; ?>">
        </div>
            <div class="col-md-6">
                <h2><?php echo $productDetails['name']; ?></h2>
                <p><?php echo $productDetails['description']; ?></p>
                <p>Price: $<?php echo $productDetails['price']; ?></p>
                <a href="cart.php?add=<?php echo $productDetails['id']; ?>" class="btn btn-primary">Add to Cart</a>
            </div>
        </div>
        <div class="row">
            <h3>Related Products</h3>
            <div class="slider">
             
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="js/slider.js"></script> 
</body>
</html>

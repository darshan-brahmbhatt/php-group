<?php
class Product {
    
    private $conn;
    private $table_name = "products";

    
    // Object properties
    public $id;
    public $name;
    public $description;
    public $price;
    public $image; 
    public $image_url;

    
    public function __construct($db) {
        $this->conn = $db;
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
    }
    public function create() {
        // Handle file upload
        if (isset($_FILES['image'])) {
            $uploadDir = 'uploads/'; // Define the upload directory
            $uploadFile = $uploadDir . basename($_FILES['image']['name']); // Define the upload file path
    
        
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
    
        
            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
        
                $this->image = $uploadFile;
            } else {
        
                echo "Sorry, there was an error uploading your file.";
                return false;
            }
        }
    
        // Create query
        $query = 'INSERT INTO ' . $this->table_name . ' SET name = :name, description = :description, price = :price, image_url = :image_url';
    
        // Prepare statement
        $stmt = $this->conn->prepare($query);
    
        // Clean data
        $this->name = htmlspecialchars(strip_tags($this->name ?? ''));
        $this->description = htmlspecialchars(strip_tags($this->description ?? ''));
        $this->price = htmlspecialchars(strip_tags($this->price ?? ''));
        $this->image_url = htmlspecialchars(strip_tags($this->image ?? '')); // Use $this->image instead of $this->image_url
    
        // Bind data
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':price', $this->price);
        $stmt->bindParam(':image_url', $this->image_url); // Ensure this is the correct property
    
        // Execute query
        if($stmt->execute()) {
            return true;
        }
    
        // Print error if something goes wrong
        printf("Error: %s.\n", $stmt->error);
    
        return false;
    }
    


    // Read products
    public function read() {
        // Create query
        $query = 'SELECT id, name, description, price, image_url FROM ' . $this->table_name;

        // Prepare statement
        $stmt = $this->conn->prepare($query);

        // Execute query
        $stmt->execute();

        return $stmt;
    }

    public function handleImageUpload($imageFile) {
        $uploadDir = 'uploads/';
        $uploadFile = $uploadDir . basename($imageFile['name']);

        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        if (move_uploaded_file($imageFile['tmp_name'], $uploadFile)) {
            $this->image_url = $uploadFile;
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // Method to update a product
    public function update() {
        // Check if a new image file is uploaded
        if (!empty($_FILES['image']['name'])) {
            // Handle file upload
            $this->handleImageUpload($_FILES['image']);
        }
    
        // Prepare the query
        $query = 'UPDATE ' . $this->table_name . ' SET name = :name, description = :description, price = :price';
    
        // Add image_url to the query if a new image is uploaded
        if (!empty($_FILES['image']['name'])) {
            $query .= ', image_url = :image_url';
        }
    
        $query .= ' WHERE id = :id';
    
        // Prepare statement
        $stmt = $this->conn->prepare($query);
    
        // Bind data
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':price', $this->price);
    
        // Bind image_url only if a new image is uploaded
        if (!empty($_FILES['image']['name'])) {
            $stmt->bindParam(':image_url', $this->image_url);
        }
    
        $stmt->bindParam(':id', $this->id);
    
        // Execute query
        if ($stmt->execute()) {
            return true;
        } else {
            printf("Error: %s.\n", $stmt->error);
            return false;
        }
    }
    
    


    // Delete product
    public function delete() {
        // Create query
        $query = 'DELETE FROM ' . $this->table_name . ' WHERE id = :id';

        // Prepare statement
        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->id = htmlspecialchars(strip_tags($this->id));

        // Bind data
        $stmt->bindParam(':id', $this->id);

        // Execute query
        if($stmt->execute()) {
            return true;
        }

        // Print error if something goes wrong
        printf("Error: %s.\n", $stmt->error);

        return false;
    }
    public function readOne($productId) {
        $query = 'SELECT id, name, description, price, image_url FROM ' . $this->table_name . ' WHERE id = :id';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $productId);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
        if ($result === false) {
            throw new Exception("Failed to fetch product details.");
        }
    
        return $result;
    }
    
    
    public function getProductDetailsById($product_id) {
        $query = "SELECT * FROM products WHERE id = :product_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':product_id', $product_id);
        $stmt->execute();
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        return $product;
    }
    public function search($query) {
        $query = "%{$query}%"; // Add wildcard characters for the LIKE query
    
        $sql = "SELECT * FROM products WHERE name LIKE :query";
        $stmt = $this->conn->prepare($sql);
    
        $stmt->bindParam(':query', $query);
    
        $stmt->execute();
    
        return $stmt;
    }
    
    public function getAll() {
        // Create query
        $query = 'SELECT id, name, description, price, image_url FROM ' . $this->table_name;
    
        // Prepare statement
        $stmt = $this->conn->prepare($query);
    
        // Execute query
        $stmt->execute();
    
        // Fetch all products
        $products = $stmt->fetchAll(PDO::FETCH_OBJ);
    
        return $products;
    }
    
    
}

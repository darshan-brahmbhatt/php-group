<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Listing</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
<div class="container-fluid">
    <div class="top-bar">
        <h2>Product Listing</h2>
        <div class="top-bar-right">
            <a href="index.php" class="btn btn-light">Home</a>
            <a href="cart.php" class="btn btn-light"><i class="fas fa-shopping-cart"></i> Cart</a>
            <a href="includes/login.php" class="btn btn-light"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        </div>
    </div>

    <div class="row">
        <!-- Sidebar for filters -->
        <div class="col-md-3">
            <h4>Filter Options</h4>
            <div class="form-group">
                <input type="text" class="form-control" id="productSearch" placeholder="Search for products...">
            </div>
        </div>

        
        
        <!-- Product Listing Container -->
        <div class="col-md-9">
            <div class="row" id="productContainer">
                <!-- Product listings will be loaded here dynamically -->
                <?php
                include_once 'includes/database.php';
                include_once 'includes/Product.php';
                include_once 'includes/Cart.php'; 

                $database = new Database();
                $db = $database->getConnection();

                $product = new Product($db);
                $stmt = $product->read();
                $num = $stmt->rowCount();

                if($num>0) {
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        extract($row);
                        echo "<div class='col-md-3'>";
                        echo "<div class='card' style='width: 100%; margin: 10px;'>";
                        echo "<img src='includes/{$image_url}' class='card-img-top' alt='{$name}'>";
                        echo "<div class='card-body'>";
                        echo "<h5 class='card-title'>{$name}</h5>";
                        echo "<p class='card-text'>Price: {$price}</p>";
                        echo "<a href='product_details.php?id={$id}' class='btn btn-primary'>View Details</a>";
                        echo "<a href='cart.php' class='btn btn-light add-to-cart' data-product-id='{$id}'><i class='fas fa-cart-plus'></i> Add to Cart</a>";
                        echo "</div>";
                        echo "</div>";
                        echo "</div>";
                    }
                } else {
                    echo "No products found.";
                }
                ?>
            </div>
        </div>
    </div>
</div>
   <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script>
    $(document).ready(function() {
        $('.add-to-cart').click(function(e) {
            e.preventDefault();
            var productId = $(this).data('product-id');
            var quantity = 1; 

            $.ajax({
                url: 'add_to_cart.php',
                type: 'POST',
                data: {action: 'add', product_id: productId, quantity: quantity},
                success: function(response) {
                    alert('Product added to cart successfully!');
                },
                error: function(xhr, status, error) {
                    alert('Error adding product to cart.');
                }
            });
        });

        $('#productSearch').on('keyup', function(e) {
        if (e.key === 'Enter') { // Check if the key pressed was Enter
            var query = $(this).val();
            if (query != '') {
                $.ajax({
                    url: 'search.php',
                    method: 'POST',
                    data: {query: query},
                    success: function(data) {
                        $('#productContainer').html(data);
                    }
                });
            } else {
                // Optionally, fetch all products if the search input is empty
                $.ajax({
                    url: 'fetch_all_products.php',
                    success: function(data) {
                        $('#productContainer').html(data);
                    }
                });
            }
        }
    });
});
</script>

</body>
</html>

<?php

include_once 'database.php';
include_once 'User.php';

$database = new Database();
$db = $database->getConnection();

// Check if form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create new User object
    $user = new User($db);

    // Set username and password from form inputs
    $user->username = $_POST['username'];
    $user->password = $_POST['password'];

    // Call login method
    $result = $user->login();

    if($result) {
        // Login successful, start session
        session_start();
        $_SESSION['user_id'] = $result['id']; // Store the user ID in the session
        $_SESSION['username'] = $user->username;

        // Check if the username is 'admin'
        if($user->username == 'admin') {
            // Redirect to dashboard
            header("Location: dashboard.php");
        } else {
            // Redirect to index.php
            header("Location: index.php");
        }
    } else {
        // Login failed, show error message
        echo "Invalid username or password.";
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background: #f8f9fa;
        }
        .login-container {
            width: 300px;
            margin: 0 auto;
            margin-top: 100px;
        }
        .logo-container {
            display: flex;
            justify-content: center;
            align-items: center;
            background: #6d4e42;
            border-radius: 50%;
            width: 80px;
            height: 80px;
            margin: 0 auto;
        }
        .logo {
            display: block;
            width: 150px;
            height:150px;
            border-radius: 50%;
        }
        .login-form {
            padding: 20px;
            border: 1px solid #ced4da;
            background: #6d4e42;
            border-radius: 5px;
            color: #fff;
            margin-top: 20px;
        }
        .forgot-password {
            display: block;
            text-align: right;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
            <div class="logo-container">
                <!-- Logo -->
                <img src="../assets\TvStore.jpg" class="logo" alt="logo">
            </div>
            <!-- Login form -->
            <form method="POST" action="login.php" class="login-form">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                <input type="submit" value="Login" class="btn btn-primary btn-block">
                <a href="#" class="forgot-password">Forgot password?</a>
            </form>
        </div>
    </div>
</body>
</html>

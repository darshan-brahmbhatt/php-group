<?php
class Order {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function createOrder($user_id, $totalPrice) {
        $query = "INSERT INTO orders (user_id, total_price) VALUES (:user_id, :total_price)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':total_price', $totalPrice);
        if ($stmt->execute()) {
            return $this->conn->lastInsertId();
        } else {
            return false;
        }
    }

    public function addProductToOrder($order_id, $product_id, $quantity) {
        $query = "INSERT INTO order_products (order_id, product_id, quantity) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $order_id);
        $stmt->bindParam(2, $product_id);
        $stmt->bindParam(3, $quantity);
        return $stmt->execute();
    }
}
?>
